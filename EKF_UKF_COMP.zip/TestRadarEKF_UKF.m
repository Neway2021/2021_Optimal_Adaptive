clear all

dt = 0.05;
t  = 0:dt:20;

Nsamples = length(t);

Xsaved = zeros(Nsamples, 3);
Zsaved = zeros(Nsamples, 1);
               
for k=1:Nsamples
  r = GetRadar(dt); 

  [posR velR altR] = RadarEKF(r, dt);  
  XsavedR(k, :) = [posR velR altR];
  ZsavedR(k)    = r;
  
  [posU velU altU] = RadarUKF(r, dt);  
  XsavedU(k, :) = [posU velU altU];
  ZsavedU(k)    = r;
  
end 


PosSavedR = XsavedR(:, 1);
VelSavedR = XsavedR(:, 2);
AltSavedR = XsavedR(:, 3);

PosSavedU = XsavedU(:, 1);
VelSavedU = XsavedU(:, 2);
AltSavedU = XsavedU(:, 3);

t = 0:dt:Nsamples*dt-dt;

% figure(1)
% plot(t, PosSaved)

figure(2)
plot(t, VelSavedR,t,VelSavedU); grid on
title('EKF estimator for the velocity =100')

figure(3); grid on
plot(t, AltSavedR,t,AltSavedU);grid on
title('EKF estimator for the altitude= 1000')

