
%% matlab_lqr
% dx = Ax + Bu 
% y = Cx 
% lqr(Q,R)
clear all; clc

A=[0 1; 0 0];
B =[0 ;1];
C =[1 0; 0 1];
D = 0;

Q = [10 0; 0 1];        %  
R =1;                     %  

[Kr, p,e] = lqr(A,B,Q,R);
poles=eig(A-B*Kr)
sys =ss(A,B,C,D);

Kc =-1/([1 0]*(inv(A-B*Kr)*B));  % for unity gain

% output feedback tp place the poles
C = [ 1 0];
Kl = (place(A', C', [-2+j*2  -2-j*2]))'

%
a_ob  = [A-Kl*C];
b_ob =[B Kl];
c_ob = eye(2);
d_ob = 0*eye(2);

sys_ob=ss(a_ob,b_ob,c_ob, d_ob);

%% LQG  with disturbance and noise
% plant : dx = Ax + Bu + Gw;
%            y = Cx + Du +Hw + v;

clear all; clc

A=[0 1; 0 0];
B =[0 ;1];
C =[1 0];
D = 0;
G = [0;1];              % disturbance matrix  in 
H = 0;         

Wn =0.0001;    % intensity
Vn  =0.001;

% W =sqrt(Wn)*G*G';
W = eye(2);
V = sqrt(Vn);

% augument sytem for amtlab 
B_aug =[B G ];                     % [u w]'
D_aug = [ 0 0];                    % u 

sys = ss(A,B_aug,C,D_aug);


% performance parameter
% for controller
Q = [10 0; 0 1];        %  
R =1;                     %  

% controller gain 
[Kr,P,E]= lqr(A,B,Q,R);
eig(A -B*Kr)
% observer gain

Kf = (lqr(A',C',W,V))';


A_f =A-Kf*C;
B_f = [B  Kf];
C_f = eye(2);
D_f = 0*[B Kf];

sys_F = ss(A_f,B_f,C_f,D_f);

eig(A_f)

Kc =-1/([1 0]*(inv(A-B*Kr)*B));  % for unity gain
%%



